3D printer [ALUNAR-M508]
filament [Alunar-PLA340�l][Pxmalion PLA]